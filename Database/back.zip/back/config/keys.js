module.exports = {
  mongoURI: 'mongodb://student:student_123@ds127841.mlab.com:27841/student',
  secretOrKey: 'secret'
};
