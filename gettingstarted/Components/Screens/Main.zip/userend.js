import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Image,
  ImageBackground,
  TextInput,
  Button,
  TouchableOpacity,
} from 'react-native';

export default class signup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      hidden: true
    };
}

  render() {
    const navigation = this.props.navigation;
    return (
      <ImageBackground style={{
        width:'100%',
        height:'100%',
      }}source={require('./Images/1.jpg')}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerText}>Smart Attendance System</Text>
        </View>
       
        <Text style={{
        //  padding: 0,
        paddingTop: 15,
        // paddingBottom: 20,
         fontSize: 30, 
         color: 'white',
         textAlign: 'center'}}>
          Welcome
        </Text>
        <TouchableOpacity style={styles.scanButton}  alighText='center' onPress={() => navigation.navigate('Login')}>
          <Text style={styles.scanButtonTexxt} >
            Scan QR Code
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.SignUpButton}  alighText='center' onPress={() => navigation.navigate('Login')}>
          <Text style={styles.SignUpButtonText} >
            Log Out
          </Text>
        </TouchableOpacity>
        <View style={styles.footer}>
            <Text style={styles.footerText}>CicHub Insternship | Group 3</Text>
          </View> 
      </View>
      </ImageBackground>
    );
  }
}
const styles = StyleSheet.create(
  {
    container: {
      flex: 1,
    },
    scanButton:{
      position: 'absolute',
      right: 180,
      bottom:100,
      backgroundColor: '#03085C',
      width: 125,
      height: 35,
      borderRadius: 50,
      justifyContent: 'center',
      elevation: 8,
    },
    scanButtonTexxt:{
      color: 'white',
      alignSelf: 'center',
    },
    footer: {
      backgroundColor: '#070F91',
      justifyContent: 'center',
      marginTop: 500,
     // borderTopWidth: 10,
      borderBottomColor: '#6C3483',
    },
    footerText: {
      color: 'white',
      fontWeight: 'bold',
      alignSelf: 'center',
      padding: 5,
   //   alignText:'center',
      fontSize: 15,
    },
    header: {
      justifyContent: 'center',
    },
    headerText: {
      color: 'white',
      fontWeight: 'bold',
      alignSelf: 'center',
      padding: 20,
      fontSize: 22,
    },
    fullName: {
      alignSelf: 'stretch',
      color: '#3A7EB0',
      padding: 3,
      marginTop: 7,
      fontSize: 12,
      marginLeft: 20,
      marginRight: 20,
    },
    pass: {
    alignSelf: 'stretch',
    color: '#3A7EB0',
    marginTop: 7,
    padding: 3,
    // backgroundColor: 'white',
    // borderTopWidth: 1,
    fontSize: 12,
    marginLeft: 20,
    marginRight: 20,
    },
    SignUpButton: {
      position: 'absolute',
      right: 40,
      bottom:100,
      backgroundColor: '#03085C',
      width: 125,
      height: 35,
      borderRadius: 50,
      justifyContent: 'center',
      elevation: 8,
    },
    SignUpButtonText:{
      color: 'white',
      alignSelf: 'center',
    },
  }
);